/**
 * Created by praveen on 5/9/14.
 */
import com.summarizer.*;
import com.google.common.io.Files;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;


public class TextSummarizer
{
    public static void main(String args[])
    {
        try{
        SimpleSummariser obj = new SimpleSummariser();
        String sdoc = Files.toString(new File("English1_sample.txt"), Charset.defaultCharset());
        sdoc = sdoc.trim();
        String[] lines = sdoc.split(".");
        String trial = obj.summariseArabic(sdoc,0.5);//REducing no of lines by 50%
        System.out.println(trial);

        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
